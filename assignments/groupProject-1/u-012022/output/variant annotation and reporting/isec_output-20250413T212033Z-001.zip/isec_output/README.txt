This file was produced by vcfisec.
The command line was:	bcftools isec  -p isec_output -n=1 proband.g.vcf.gz parents.vcf.gz

Using the following file names:
isec_output/0000.vcf	for stripped	proband.g.vcf.gz
isec_output/0001.vcf	for stripped	parents.vcf.gz
